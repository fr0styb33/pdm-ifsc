package exercicio1;

class q1 {
	
// 1-Encapsulamento, 2- Herança, 3-Polimorfismo e 4-Abstração
// O encapsulamento agrupa dados e operações relacionadas em uma classe, controlando o acesso aos dados internos, já
// a herança, permite que classes herdem atributos e métodos de outras classes, promovendo a reutilização de código e 
// hierarquias de classes. O polimorfismo permite tratar objetos diferentes de maneira uniforme através de uma interface
//comum, facilitando a manipulação de tipos diversos e a abstração cria classes abstratas e interfaces para definir funcionalidades 
//essenciais, separando a definição da implementação concreta.


}
