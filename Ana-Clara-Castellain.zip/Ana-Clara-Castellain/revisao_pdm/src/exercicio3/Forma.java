package exercicio3;

public abstract class Forma {
    
    public abstract double area();

    public abstract double perimetro();
}